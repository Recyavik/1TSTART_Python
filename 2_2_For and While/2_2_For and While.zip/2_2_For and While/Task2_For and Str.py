# ЦИКЛ for (алгоритмическая структура перебора последовательности)
# Задача 1. Перебор символов в строке

liters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
i = 0
for liter in liters:
    # print(liter, end=',')
    i = i + 1
    print(i, "- символ = ", liter)

print()
for i in range(len(liters)):
    print(i+1, "- символ = ", liters[i])

print()
for i in range(0, len(liters), 3):
    print(i+1, "- символ = ", liters[i])

for chr in 'aabb7ccc': # параметр chr посимвольно пройдет по всей строке
    if chr.isdigit(): # если в одном из символов строки появится цифра,
        break # то цикл прервется
    print(chr, end='')

for i in range(1, 10): # запуск вывода чисел от 1 до 10 не включительно
    if i % 3 == 0: # если параметр цикла будет кратен 3 (такие числа как 3,6,9)
        continue # то этот параметр будет пропущен и цикл перейдет на следующий шаг
    print(i,end=' ')

# Сегодня на практике - ЦИКЛ for (алгоритмическая структура перебора последовательности)
# Задача 2. Перебор чисел последовательности
import random as rnd
import math


for x in range(1, 15, 1):
    if x % 2 == 0:
        print(x, end=' ')

print()
for x in range(2, 15, 2):
    print(x, end=' ')

print()
for i in range(0, 5):
    a = rnd.randint(10, 99)
    x = math.sqrt(a)
    print(a, "его корень квадратный =", x)