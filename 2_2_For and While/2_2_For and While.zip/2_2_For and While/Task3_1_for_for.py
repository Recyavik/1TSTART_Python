# Вложенные циклы
import turtle
# turtle.speed(0)
turtle.pencolor('red')
turtle.pensize(3)
for j in range(14): # 0,1,2,3,4,5,6,7,8,9,10,11,12,13 - всего 14
    for i in range(4): # внутренний цикл
        turtle.forward(40)
        turtle.right(90)
    turtle.left(25)
    turtle.backward(60)